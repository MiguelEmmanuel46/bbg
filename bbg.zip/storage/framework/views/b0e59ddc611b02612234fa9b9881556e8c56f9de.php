<h1><?php echo e($titulo); ?></h1>
<ul>
 <?php $__currentLoopData = $animales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <li><?php echo e($animal); ?></li>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </ul><?php /**PATH C:\xampp\htdocs\bbg\resources\views/pruebas/index.blade.php ENDPATH**/ ?>