<?php 
echo $texto;
 ?>