<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<style type="text/css">
		body{
			font-family: 'Verdana';
			font-size: 15px;
		}
		h1{
			font-size: 20px;
			font-weight: bold;
			text-decoration: underline;
		}
	</style>
</head>
<body>
	<h1>Mensaje de  <?php echo e($name); ?></h1>
	<p>Telefono: <?php echo e($telefono); ?></p>
        <p>Email: <?php echo e($email); ?></p>
        <p>Mensaje: </p>
        <p><?php echo e($mensaje); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\bbg\resources\views/contacto.blade.php ENDPATH**/ ?>